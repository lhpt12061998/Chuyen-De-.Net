﻿namespace BT02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Winner");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Exciter");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Xe May", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2});
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Toyota");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("BMW");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("O To", new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode5});
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Xe", new System.Windows.Forms.TreeNode[] {
            treeNode3,
            treeNode6});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.txt_TongTien = new System.Windows.Forms.TextBox();
            this.nud_SoLuong = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.trv_DanhSachXe = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.dud_ThongTinMuaHang = new System.Windows.Forms.DomainUpDown();
            this.btn_Thoat = new System.Windows.Forms.Button();
            this.btn_LuuTru = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.lsv_ThongTinXe = new System.Windows.Forms.ListView();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SoLuong)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.txt_TongTien);
            this.splitContainer1.Panel1.Controls.Add(this.nud_SoLuong);
            this.splitContainer1.Panel1.Controls.Add(this.label4);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.trv_DanhSachXe);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dud_ThongTinMuaHang);
            this.splitContainer1.Panel2.Controls.Add(this.btn_Thoat);
            this.splitContainer1.Panel2.Controls.Add(this.btn_LuuTru);
            this.splitContainer1.Panel2.Controls.Add(this.label5);
            this.splitContainer1.Panel2.Controls.Add(this.lsv_ThongTinXe);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Size = new System.Drawing.Size(882, 453);
            this.splitContainer1.SplitterDistance = 314;
            this.splitContainer1.TabIndex = 0;
            // 
            // txt_TongTien
            // 
            this.txt_TongTien.Location = new System.Drawing.Point(112, 396);
            this.txt_TongTien.Name = "txt_TongTien";
            this.txt_TongTien.Size = new System.Drawing.Size(180, 22);
            this.txt_TongTien.TabIndex = 5;
            // 
            // nud_SoLuong
            // 
            this.nud_SoLuong.Location = new System.Drawing.Point(112, 355);
            this.nud_SoLuong.Name = "nud_SoLuong";
            this.nud_SoLuong.Size = new System.Drawing.Size(180, 22);
            this.nud_SoLuong.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 399);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tong tien";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 357);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "So luong";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Danh sach xe";
            // 
            // trv_DanhSachXe
            // 
            this.trv_DanhSachXe.ImageIndex = 0;
            this.trv_DanhSachXe.ImageList = this.imageList1;
            this.trv_DanhSachXe.Location = new System.Drawing.Point(12, 54);
            this.trv_DanhSachXe.Name = "trv_DanhSachXe";
            treeNode1.ImageKey = "Winner.jpg";
            treeNode1.Name = "Node11";
            treeNode1.SelectedImageKey = "Winner.jpg";
            treeNode1.Text = "Winner";
            treeNode2.ImageKey = "Exciter.jpg";
            treeNode2.Name = "Node12";
            treeNode2.SelectedImageKey = "Exciter.jpg";
            treeNode2.Text = "Exciter";
            treeNode3.ImageKey = "XeMay.jpg";
            treeNode3.Name = "Node1";
            treeNode3.SelectedImageKey = "XeMay.jpg";
            treeNode3.Text = "Xe May";
            treeNode4.ImageKey = "Toyota.jpg";
            treeNode4.Name = "Node21";
            treeNode4.SelectedImageKey = "Toyota.jpg";
            treeNode4.Text = "Toyota";
            treeNode5.ImageKey = "BMW.jpg";
            treeNode5.Name = "Node22";
            treeNode5.SelectedImageKey = "BMW.jpg";
            treeNode5.Text = "BMW";
            treeNode6.ImageKey = "Oto.jpg";
            treeNode6.Name = "Node2";
            treeNode6.SelectedImageKey = "Oto.jpg";
            treeNode6.Text = "O To";
            treeNode7.ImageKey = "Xe.jpg";
            treeNode7.Name = "NodeRoot";
            treeNode7.SelectedImageKey = "Xe.jpg";
            treeNode7.Text = "Xe";
            this.trv_DanhSachXe.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode7});
            this.trv_DanhSachXe.SelectedImageIndex = 0;
            this.trv_DanhSachXe.Size = new System.Drawing.Size(280, 280);
            this.trv_DanhSachXe.TabIndex = 0;
            this.trv_DanhSachXe.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.trv_DanhSachXe_AfterSelect);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "BMW.jpg");
            this.imageList1.Images.SetKeyName(1, "Exciter.jpg");
            this.imageList1.Images.SetKeyName(2, "Oto.jpg");
            this.imageList1.Images.SetKeyName(3, "Toyota.jpg");
            this.imageList1.Images.SetKeyName(4, "Winner.jpg");
            this.imageList1.Images.SetKeyName(5, "Xe.jpg");
            this.imageList1.Images.SetKeyName(6, "XeMay.jpg");
            // 
            // dud_ThongTinMuaHang
            // 
            this.dud_ThongTinMuaHang.AllowDrop = true;
            this.dud_ThongTinMuaHang.Location = new System.Drawing.Point(183, 356);
            this.dud_ThongTinMuaHang.Name = "dud_ThongTinMuaHang";
            this.dud_ThongTinMuaHang.ReadOnly = true;
            this.dud_ThongTinMuaHang.Size = new System.Drawing.Size(369, 22);
            this.dud_ThongTinMuaHang.TabIndex = 6;
            // 
            // btn_Thoat
            // 
            this.btn_Thoat.Location = new System.Drawing.Point(456, 396);
            this.btn_Thoat.Name = "btn_Thoat";
            this.btn_Thoat.Size = new System.Drawing.Size(96, 34);
            this.btn_Thoat.TabIndex = 5;
            this.btn_Thoat.Text = "Thoat";
            this.btn_Thoat.UseVisualStyleBackColor = true;
            this.btn_Thoat.Click += new System.EventHandler(this.btn_Thoat_Click);
            // 
            // btn_LuuTru
            // 
            this.btn_LuuTru.Location = new System.Drawing.Point(343, 396);
            this.btn_LuuTru.Name = "btn_LuuTru";
            this.btn_LuuTru.Size = new System.Drawing.Size(96, 34);
            this.btn_LuuTru.TabIndex = 4;
            this.btn_LuuTru.Text = "Luu tru";
            this.btn_LuuTru.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 357);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "Thong tin mua hang";
            // 
            // lsv_ThongTinXe
            // 
            this.lsv_ThongTinXe.Location = new System.Drawing.Point(15, 54);
            this.lsv_ThongTinXe.Name = "lsv_ThongTinXe";
            this.lsv_ThongTinXe.Size = new System.Drawing.Size(537, 280);
            this.lsv_ThongTinXe.TabIndex = 1;
            this.lsv_ThongTinXe.UseCompatibleStateImageBehavior = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Thong tin chi tiet ve xe";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(882, 453);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nud_SoLuong)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView trv_DanhSachXe;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TextBox txt_TongTien;
        private System.Windows.Forms.NumericUpDown nud_SoLuong;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Thoat;
        private System.Windows.Forms.Button btn_LuuTru;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListView lsv_ThongTinXe;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DomainUpDown dud_ThongTinMuaHang;
    }
}

