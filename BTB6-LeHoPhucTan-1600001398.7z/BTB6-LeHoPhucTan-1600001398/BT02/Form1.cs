﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BT02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dud_ThongTinMuaHang.Items.Add("Tra Gop");
            dud_ThongTinMuaHang.Items.Add("Khoan Gop");
            dud_ThongTinMuaHang.Items.Add("Bao Hiem");
        }



        //Hien het list
        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            trv_DanhSachXe.ExpandAll();
        }

        //Thoat
        private void btn_Thoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void trv_DanhSachXe_AfterSelect(object sender, TreeViewEventArgs e)
        {
           
        }
    }
}
