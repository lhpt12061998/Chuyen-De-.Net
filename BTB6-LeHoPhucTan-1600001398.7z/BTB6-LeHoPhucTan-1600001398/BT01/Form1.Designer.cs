﻿namespace BT01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.lk_google = new System.Windows.Forms.LinkLabel();
            this.lk_BaoDienTu = new System.Windows.Forms.LinkLabel();
            this.lk_ShopThoiTrang = new System.Windows.Forms.LinkLabel();
            this.lk_BaoTheThao = new System.Windows.Forms.LinkLabel();
            this.lk_BaoTuoiTre = new System.Windows.Forms.LinkLabel();
            this.lk_BaoCongAn = new System.Windows.Forms.LinkLabel();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lk_BaoCongAn);
            this.splitContainer1.Panel1.Controls.Add(this.lk_BaoTuoiTre);
            this.splitContainer1.Panel1.Controls.Add(this.lk_BaoTheThao);
            this.splitContainer1.Panel1.Controls.Add(this.lk_ShopThoiTrang);
            this.splitContainer1.Panel1.Controls.Add(this.lk_BaoDienTu);
            this.splitContainer1.Panel1.Controls.Add(this.lk_google);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.webBrowser1);
            this.splitContainer1.Size = new System.Drawing.Size(782, 413);
            this.splitContainer1.SplitterDistance = 249;
            this.splitContainer1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Chon link muon truy cap";
            // 
            // lk_google
            // 
            this.lk_google.AutoSize = true;
            this.lk_google.Location = new System.Drawing.Point(20, 50);
            this.lk_google.Name = "lk_google";
            this.lk_google.Size = new System.Drawing.Size(54, 17);
            this.lk_google.TabIndex = 1;
            this.lk_google.TabStop = true;
            this.lk_google.Text = "Google";
            this.lk_google.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lk_google_LinkClicked);
            // 
            // lk_BaoDienTu
            // 
            this.lk_BaoDienTu.AutoSize = true;
            this.lk_BaoDienTu.Location = new System.Drawing.Point(20, 100);
            this.lk_BaoDienTu.Name = "lk_BaoDienTu";
            this.lk_BaoDienTu.Size = new System.Drawing.Size(87, 17);
            this.lk_BaoDienTu.TabIndex = 2;
            this.lk_BaoDienTu.TabStop = true;
            this.lk_BaoDienTu.Text = "Bao Dien Tu";
            this.lk_BaoDienTu.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lk_BaoDienTu_LinkClicked);
            // 
            // lk_ShopThoiTrang
            // 
            this.lk_ShopThoiTrang.AutoSize = true;
            this.lk_ShopThoiTrang.Location = new System.Drawing.Point(20, 150);
            this.lk_ShopThoiTrang.Name = "lk_ShopThoiTrang";
            this.lk_ShopThoiTrang.Size = new System.Drawing.Size(115, 17);
            this.lk_ShopThoiTrang.TabIndex = 3;
            this.lk_ShopThoiTrang.TabStop = true;
            this.lk_ShopThoiTrang.Text = "Shop Thoi Trang";
            this.lk_ShopThoiTrang.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lk_ShopThoiTrang_LinkClicked);
            // 
            // lk_BaoTheThao
            // 
            this.lk_BaoTheThao.AutoSize = true;
            this.lk_BaoTheThao.Location = new System.Drawing.Point(20, 200);
            this.lk_BaoTheThao.Name = "lk_BaoTheThao";
            this.lk_BaoTheThao.Size = new System.Drawing.Size(99, 17);
            this.lk_BaoTheThao.TabIndex = 4;
            this.lk_BaoTheThao.TabStop = true;
            this.lk_BaoTheThao.Text = "Bao The Thao";
            this.lk_BaoTheThao.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lk_BaoTheThao_LinkClicked);
            // 
            // lk_BaoTuoiTre
            // 
            this.lk_BaoTuoiTre.AutoSize = true;
            this.lk_BaoTuoiTre.Location = new System.Drawing.Point(20, 250);
            this.lk_BaoTuoiTre.Name = "lk_BaoTuoiTre";
            this.lk_BaoTuoiTre.Size = new System.Drawing.Size(91, 17);
            this.lk_BaoTuoiTre.TabIndex = 5;
            this.lk_BaoTuoiTre.TabStop = true;
            this.lk_BaoTuoiTre.Text = "Bao Tuoi Tre";
            this.lk_BaoTuoiTre.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lk_BaoTuoiTre_LinkClicked);
            // 
            // lk_BaoCongAn
            // 
            this.lk_BaoCongAn.AutoSize = true;
            this.lk_BaoCongAn.Location = new System.Drawing.Point(20, 300);
            this.lk_BaoCongAn.Name = "lk_BaoCongAn";
            this.lk_BaoCongAn.Size = new System.Drawing.Size(91, 17);
            this.lk_BaoCongAn.TabIndex = 6;
            this.lk_BaoCongAn.TabStop = true;
            this.lk_BaoCongAn.Text = "Bao Cong An";
            this.lk_BaoCongAn.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lk_BaoCongAn_LinkClicked);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(529, 413);
            this.webBrowser1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 413);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.LinkLabel lk_BaoCongAn;
        private System.Windows.Forms.LinkLabel lk_BaoTuoiTre;
        private System.Windows.Forms.LinkLabel lk_BaoTheThao;
        private System.Windows.Forms.LinkLabel lk_ShopThoiTrang;
        private System.Windows.Forms.LinkLabel lk_BaoDienTu;
        private System.Windows.Forms.LinkLabel lk_google;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.WebBrowser webBrowser1;
    }
}

