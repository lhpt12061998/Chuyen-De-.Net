﻿namespace BT01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtNhapSo = new System.Windows.Forms.TextBox();
            this.btnCapNhat = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbLopA = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnChonSoLe = new System.Windows.Forms.Button();
            this.btnChonSoChan = new System.Windows.Forms.Button();
            this.btnThayBangBinhPhuong = new System.Windows.Forms.Button();
            this.btnTangMoiPTLen2 = new System.Windows.Forms.Button();
            this.btnXoaPTDangChon = new System.Windows.Forms.Button();
            this.btnXoaPTDauVaCuoi = new System.Windows.Forms.Button();
            this.btnTongcuaDS = new System.Windows.Forms.Button();
            this.btnKetThuc = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nhap So";
            // 
            // txtNhapSo
            // 
            this.txtNhapSo.Location = new System.Drawing.Point(145, 12);
            this.txtNhapSo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNhapSo.Name = "txtNhapSo";
            this.txtNhapSo.Size = new System.Drawing.Size(217, 22);
            this.txtNhapSo.TabIndex = 1;
            this.txtNhapSo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNhapSo_KeyPress);
            // 
            // btnCapNhat
            // 
            this.btnCapNhat.Location = new System.Drawing.Point(372, 10);
            this.btnCapNhat.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCapNhat.Name = "btnCapNhat";
            this.btnCapNhat.Size = new System.Drawing.Size(141, 28);
            this.btnCapNhat.TabIndex = 2;
            this.btnCapNhat.Text = "Cap nhat";
            this.btnCapNhat.UseVisualStyleBackColor = true;
            this.btnCapNhat.Click += new System.EventHandler(this.btnCapNhat_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbLopA);
            this.groupBox1.Location = new System.Drawing.Point(16, 57);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(227, 283);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lop A";
            // 
            // lbLopA
            // 
            this.lbLopA.FormattingEnabled = true;
            this.lbLopA.ItemHeight = 16;
            this.lbLopA.Location = new System.Drawing.Point(13, 25);
            this.lbLopA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lbLopA.MultiColumn = true;
            this.lbLopA.Name = "lbLopA";
            this.lbLopA.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lbLopA.Size = new System.Drawing.Size(195, 244);
            this.lbLopA.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnChonSoLe);
            this.groupBox2.Controls.Add(this.btnChonSoChan);
            this.groupBox2.Controls.Add(this.btnThayBangBinhPhuong);
            this.groupBox2.Controls.Add(this.btnTangMoiPTLen2);
            this.groupBox2.Controls.Add(this.btnXoaPTDangChon);
            this.groupBox2.Controls.Add(this.btnXoaPTDauVaCuoi);
            this.groupBox2.Controls.Add(this.btnTongcuaDS);
            this.groupBox2.Location = new System.Drawing.Point(269, 57);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(240, 283);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Cac chuc nang";
            // 
            // btnChonSoLe
            // 
            this.btnChonSoLe.Location = new System.Drawing.Point(9, 245);
            this.btnChonSoLe.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnChonSoLe.Name = "btnChonSoLe";
            this.btnChonSoLe.Size = new System.Drawing.Size(220, 28);
            this.btnChonSoLe.TabIndex = 6;
            this.btnChonSoLe.Text = "Chon so le";
            this.btnChonSoLe.UseVisualStyleBackColor = true;
            this.btnChonSoLe.Click += new System.EventHandler(this.btnChonSoLe_Click);
            // 
            // btnChonSoChan
            // 
            this.btnChonSoChan.Location = new System.Drawing.Point(9, 209);
            this.btnChonSoChan.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnChonSoChan.Name = "btnChonSoChan";
            this.btnChonSoChan.Size = new System.Drawing.Size(220, 28);
            this.btnChonSoChan.TabIndex = 5;
            this.btnChonSoChan.Text = "Chon so chan";
            this.btnChonSoChan.UseVisualStyleBackColor = true;
            this.btnChonSoChan.Click += new System.EventHandler(this.btnChonSoChan_Click);
            // 
            // btnThayBangBinhPhuong
            // 
            this.btnThayBangBinhPhuong.Location = new System.Drawing.Point(9, 172);
            this.btnThayBangBinhPhuong.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnThayBangBinhPhuong.Name = "btnThayBangBinhPhuong";
            this.btnThayBangBinhPhuong.Size = new System.Drawing.Size(220, 28);
            this.btnThayBangBinhPhuong.TabIndex = 4;
            this.btnThayBangBinhPhuong.Text = "Thay bang binh phuong";
            this.btnThayBangBinhPhuong.UseVisualStyleBackColor = true;
            this.btnThayBangBinhPhuong.Click += new System.EventHandler(this.btnThayBangBinhPhuong_Click);
            // 
            // btnTangMoiPTLen2
            // 
            this.btnTangMoiPTLen2.Location = new System.Drawing.Point(9, 135);
            this.btnTangMoiPTLen2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTangMoiPTLen2.Name = "btnTangMoiPTLen2";
            this.btnTangMoiPTLen2.Size = new System.Drawing.Size(220, 28);
            this.btnTangMoiPTLen2.TabIndex = 3;
            this.btnTangMoiPTLen2.Text = "Tang moi phan tu len 2";
            this.btnTangMoiPTLen2.UseVisualStyleBackColor = true;
            this.btnTangMoiPTLen2.Click += new System.EventHandler(this.btnTangMoiPTLen2_Click);
            // 
            // btnXoaPTDangChon
            // 
            this.btnXoaPTDangChon.Location = new System.Drawing.Point(9, 98);
            this.btnXoaPTDangChon.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnXoaPTDangChon.Name = "btnXoaPTDangChon";
            this.btnXoaPTDangChon.Size = new System.Drawing.Size(220, 28);
            this.btnXoaPTDangChon.TabIndex = 2;
            this.btnXoaPTDangChon.Text = "Xoa phan tu dang chon";
            this.btnXoaPTDangChon.UseVisualStyleBackColor = true;
            this.btnXoaPTDangChon.Click += new System.EventHandler(this.btnXoaPTDangChon_Click);
            // 
            // btnXoaPTDauVaCuoi
            // 
            this.btnXoaPTDauVaCuoi.Location = new System.Drawing.Point(9, 62);
            this.btnXoaPTDauVaCuoi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnXoaPTDauVaCuoi.Name = "btnXoaPTDauVaCuoi";
            this.btnXoaPTDauVaCuoi.Size = new System.Drawing.Size(220, 28);
            this.btnXoaPTDauVaCuoi.TabIndex = 1;
            this.btnXoaPTDauVaCuoi.Text = "Xoa phan tu dau va cuoi";
            this.btnXoaPTDauVaCuoi.UseVisualStyleBackColor = true;
            this.btnXoaPTDauVaCuoi.Click += new System.EventHandler(this.btnXoaPTDauVaCuoi_Click);
            // 
            // btnTongcuaDS
            // 
            this.btnTongcuaDS.Location = new System.Drawing.Point(9, 25);
            this.btnTongcuaDS.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTongcuaDS.Name = "btnTongcuaDS";
            this.btnTongcuaDS.Size = new System.Drawing.Size(220, 28);
            this.btnTongcuaDS.TabIndex = 0;
            this.btnTongcuaDS.Text = "Tong cua danh sach";
            this.btnTongcuaDS.UseVisualStyleBackColor = true;
            this.btnTongcuaDS.Click += new System.EventHandler(this.btnTongcuaDS_Click);
            // 
            // btnKetThuc
            // 
            this.btnKetThuc.Location = new System.Drawing.Point(16, 347);
            this.btnKetThuc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnKetThuc.Name = "btnKetThuc";
            this.btnKetThuc.Size = new System.Drawing.Size(493, 28);
            this.btnKetThuc.TabIndex = 5;
            this.btnKetThuc.Text = "KET THUC";
            this.btnKetThuc.UseVisualStyleBackColor = true;
            this.btnKetThuc.Click += new System.EventHandler(this.btnKetThuc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 384);
            this.Controls.Add(this.btnKetThuc);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCapNhat);
            this.Controls.Add(this.txtNhapSo);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNhapSo;
        private System.Windows.Forms.Button btnCapNhat;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox lbLopA;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnChonSoLe;
        private System.Windows.Forms.Button btnChonSoChan;
        private System.Windows.Forms.Button btnThayBangBinhPhuong;
        private System.Windows.Forms.Button btnTangMoiPTLen2;
        private System.Windows.Forms.Button btnXoaPTDangChon;
        private System.Windows.Forms.Button btnXoaPTDauVaCuoi;
        private System.Windows.Forms.Button btnTongcuaDS;
        private System.Windows.Forms.Button btnKetThuc;
    }
}

