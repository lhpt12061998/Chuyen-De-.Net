﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BT01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Chi nhap so
        private void txtNhapSo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) /*&& !string.IsNullOrEmpty(txtNhapSo.text)*/)
                e.Handled = true;
        }

        //Cap nhat
        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            lbLopA.Items.Add(txtNhapSo.Text);
            txtNhapSo.Clear();
            txtNhapSo.Focus();
        }

        //Tong cac phan tu cua DS
        private void btnTongcuaDS_Click(object sender, EventArgs e)
        {
            double tong = 0;
            foreach (string so in lbLopA.Items)
            {
                tong += double.Parse(so);
            }
            MessageBox.Show("Tong cac phan tu trong listbox : " + tong.ToString());
        }

        //Xoa phan tu dang chon
        private void btnXoaPTDangChon_Click(object sender, EventArgs e)
        {
          lbLopA.Items.RemoveAt(lbLopA.SelectedIndex);
        }

        //Xoa tu dau va cuoi
        private void btnXoaPTDauVaCuoi_Click(object sender, EventArgs e)
        {
            lbLopA.Items.RemoveAt(lbLopA.Items.Count - 1);
            lbLopA.Items.RemoveAt(0);
            
        }

        //Tang moi phan tu len 2
        private void btnTangMoiPTLen2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lbLopA.Items.Count ; i++)
            {
                int tang = int.Parse((lbLopA.Items[i].ToString()));
                tang += 2;
                lbLopA.Items[i] = tang.ToString();     
            }
        }

        //Tang bang binh phuong
        private void btnThayBangBinhPhuong_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lbLopA.Items.Count; i++)
            {
                double tang = double.Parse((lbLopA.Items[i].ToString()));
                tang += Math.Pow(tang,2);
                lbLopA.Items[i] = tang.ToString();
            }
        }

        //Chon so chan
        private void btnChonSoChan_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lbLopA.Items.Count; i++)
            {
                int cchan = int.Parse((lbLopA.Items[i].ToString()));
                if (cchan % 2 == 0)
                    //lbLopA.SetSelected(i, true);
                    lbLopA.SetSelected(i, true);
            }
        }

        //Chon so le
        private void btnChonSoLe_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lbLopA.Items.Count; i++)
            {
                int cchan = int.Parse((lbLopA.Items[i].ToString()));
                if (cchan % 2 == 1)
                    lbLopA.SetSelected(i, true);
            }
        }

        //Ket Thuc
        private void btnKetThuc_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
