﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BT02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Chi nhap ky tu
        private void txtTenSV_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !((e.KeyChar >= 65 && e.KeyChar <= 122)) || (e.KeyChar == 0);
        }

        //Cap nhat
        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            lsbA.Items.Add(txtTenSV.Text);
            txtTenSV.Clear();
            txtTenSV.Focus();
        }

        //Ket thuc
        private void btnKetThuc_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Cac nut chuyen
        private void btnPhai1_Click(object sender, EventArgs e)
        {
            if (lsbA.SelectedItem != null)
                lsbB.Items.Add(lsbA.SelectedItem);
            else
                MessageBox.Show("Choose one item!");
            lsbA.Items.Remove(lsbA.SelectedItem);
        }
        private void btnPhaiHet_Click(object sender, EventArgs e)
        {
            lsbB.Items.AddRange(lsbA.Items);
            lsbA.Items.Clear();
        }

        private void btnTrai1_Click(object sender, EventArgs e)
        {
            if (lsbB.SelectedItem != null)
                lsbA.Items.Add(lsbB.SelectedItem);
            else
                MessageBox.Show("Choose one item!");
            lsbB.Items.Remove(lsbB.SelectedItem);
        }
        private void btnTraiHet_Click(object sender, EventArgs e)
        {
            lsbA.Items.AddRange(lsbB.Items);
            lsbB.Items.Clear();
        }

        //Xoa lop A
        private void btnXoaLopA_Click(object sender, EventArgs e)
        {
            lsbA.Items.Clear();
        }
        //Xoa lop B
        private void btnXoaLopB_Click(object sender, EventArgs e)
        {
            lsbB.Items.Clear();
        }
    }
}
