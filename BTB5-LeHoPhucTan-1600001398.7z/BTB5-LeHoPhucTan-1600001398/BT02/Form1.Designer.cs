﻿namespace BT02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtTenSV = new System.Windows.Forms.TextBox();
            this.btnCapNhat = new System.Windows.Forms.Button();
            this.lsbA = new System.Windows.Forms.ListBox();
            this.lsbB = new System.Windows.Forms.ListBox();
            this.btnPhai1 = new System.Windows.Forms.Button();
            this.btnPhaiHet = new System.Windows.Forms.Button();
            this.btnTrai1 = new System.Windows.Forms.Button();
            this.btnTraiHet = new System.Windows.Forms.Button();
            this.btnXoaLopA = new System.Windows.Forms.Button();
            this.btnKetThuc = new System.Windows.Forms.Button();
            this.btnXoaLopB = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ten SV :";
            // 
            // txtTenSV
            // 
            this.txtTenSV.Location = new System.Drawing.Point(127, 19);
            this.txtTenSV.Name = "txtTenSV";
            this.txtTenSV.Size = new System.Drawing.Size(182, 22);
            this.txtTenSV.TabIndex = 1;
            this.txtTenSV.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTenSV_KeyPress);
            // 
            // btnCapNhat
            // 
            this.btnCapNhat.Location = new System.Drawing.Point(315, 16);
            this.btnCapNhat.Name = "btnCapNhat";
            this.btnCapNhat.Size = new System.Drawing.Size(143, 30);
            this.btnCapNhat.TabIndex = 2;
            this.btnCapNhat.Text = "Cap Nhat";
            this.btnCapNhat.UseVisualStyleBackColor = true;
            this.btnCapNhat.Click += new System.EventHandler(this.btnCapNhat_Click);
            // 
            // lsbA
            // 
            this.lsbA.FormattingEnabled = true;
            this.lsbA.ItemHeight = 16;
            this.lsbA.Location = new System.Drawing.Point(35, 59);
            this.lsbA.Name = "lsbA";
            this.lsbA.Size = new System.Drawing.Size(160, 196);
            this.lsbA.TabIndex = 3;
            // 
            // lsbB
            // 
            this.lsbB.FormattingEnabled = true;
            this.lsbB.ItemHeight = 16;
            this.lsbB.Location = new System.Drawing.Point(298, 59);
            this.lsbB.Name = "lsbB";
            this.lsbB.Size = new System.Drawing.Size(160, 196);
            this.lsbB.TabIndex = 4;
            // 
            // btnPhai1
            // 
            this.btnPhai1.Location = new System.Drawing.Point(209, 61);
            this.btnPhai1.Name = "btnPhai1";
            this.btnPhai1.Size = new System.Drawing.Size(75, 40);
            this.btnPhai1.TabIndex = 5;
            this.btnPhai1.Text = ">";
            this.btnPhai1.UseVisualStyleBackColor = true;
            this.btnPhai1.Click += new System.EventHandler(this.btnPhai1_Click);
            // 
            // btnPhaiHet
            // 
            this.btnPhaiHet.Location = new System.Drawing.Point(209, 107);
            this.btnPhaiHet.Name = "btnPhaiHet";
            this.btnPhaiHet.Size = new System.Drawing.Size(75, 40);
            this.btnPhaiHet.TabIndex = 6;
            this.btnPhaiHet.Text = ">>";
            this.btnPhaiHet.UseVisualStyleBackColor = true;
            this.btnPhaiHet.Click += new System.EventHandler(this.btnPhaiHet_Click);
            // 
            // btnTrai1
            // 
            this.btnTrai1.Location = new System.Drawing.Point(209, 169);
            this.btnTrai1.Name = "btnTrai1";
            this.btnTrai1.Size = new System.Drawing.Size(75, 40);
            this.btnTrai1.TabIndex = 7;
            this.btnTrai1.Text = "<";
            this.btnTrai1.UseVisualStyleBackColor = true;
            this.btnTrai1.Click += new System.EventHandler(this.btnTrai1_Click);
            // 
            // btnTraiHet
            // 
            this.btnTraiHet.Location = new System.Drawing.Point(209, 215);
            this.btnTraiHet.Name = "btnTraiHet";
            this.btnTraiHet.Size = new System.Drawing.Size(75, 40);
            this.btnTraiHet.TabIndex = 8;
            this.btnTraiHet.Text = "<<";
            this.btnTraiHet.UseVisualStyleBackColor = true;
            this.btnTraiHet.Click += new System.EventHandler(this.btnTraiHet_Click);
            // 
            // btnXoaLopA
            // 
            this.btnXoaLopA.Location = new System.Drawing.Point(35, 271);
            this.btnXoaLopA.Name = "btnXoaLopA";
            this.btnXoaLopA.Size = new System.Drawing.Size(135, 35);
            this.btnXoaLopA.TabIndex = 9;
            this.btnXoaLopA.Text = "Xoa lop A";
            this.btnXoaLopA.UseVisualStyleBackColor = true;
            this.btnXoaLopA.Click += new System.EventHandler(this.btnXoaLopA_Click);
            // 
            // btnKetThuc
            // 
            this.btnKetThuc.Location = new System.Drawing.Point(176, 271);
            this.btnKetThuc.Name = "btnKetThuc";
            this.btnKetThuc.Size = new System.Drawing.Size(141, 35);
            this.btnKetThuc.TabIndex = 10;
            this.btnKetThuc.Text = "Ket thuc";
            this.btnKetThuc.UseVisualStyleBackColor = true;
            this.btnKetThuc.Click += new System.EventHandler(this.btnKetThuc_Click);
            // 
            // btnXoaLopB
            // 
            this.btnXoaLopB.Location = new System.Drawing.Point(323, 271);
            this.btnXoaLopB.Name = "btnXoaLopB";
            this.btnXoaLopB.Size = new System.Drawing.Size(135, 35);
            this.btnXoaLopB.TabIndex = 11;
            this.btnXoaLopB.Text = "Xoa lop B";
            this.btnXoaLopB.UseVisualStyleBackColor = true;
            this.btnXoaLopB.Click += new System.EventHandler(this.btnXoaLopB_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(497, 333);
            this.Controls.Add(this.btnXoaLopB);
            this.Controls.Add(this.btnKetThuc);
            this.Controls.Add(this.btnXoaLopA);
            this.Controls.Add(this.btnTraiHet);
            this.Controls.Add(this.btnTrai1);
            this.Controls.Add(this.btnPhaiHet);
            this.Controls.Add(this.btnPhai1);
            this.Controls.Add(this.lsbB);
            this.Controls.Add(this.lsbA);
            this.Controls.Add(this.btnCapNhat);
            this.Controls.Add(this.txtTenSV);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTenSV;
        private System.Windows.Forms.Button btnCapNhat;
        private System.Windows.Forms.ListBox lsbA;
        private System.Windows.Forms.ListBox lsbB;
        private System.Windows.Forms.Button btnPhai1;
        private System.Windows.Forms.Button btnPhaiHet;
        private System.Windows.Forms.Button btnTrai1;
        private System.Windows.Forms.Button btnTraiHet;
        private System.Windows.Forms.Button btnXoaLopA;
        private System.Windows.Forms.Button btnKetThuc;
        private System.Windows.Forms.Button btnXoaLopB;
    }
}

