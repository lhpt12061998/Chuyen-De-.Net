﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BT5
{
    public partial class Form1 : Form 
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Button btn = new Button();
            btn.Width = 100;
            btn.Height = 50;
            btn.ForeColor = Color.Black;
            var moc = btnMoc.Location;
            btn.Location = new Point(moc.X, (moc.Y - 50));

            btn.Text = "Element";

            //var form = new Form1();
            //var main = this.Location;
            //form.Location = new Point((main.X + 600), main.Y);
            //form.Show();



            //This will work and add button to your Form.
            this.Controls.Add(btn);

        }
    }
    
}
