﻿namespace BT1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNhapPass = new System.Windows.Forms.Label();
            this.lblHienThi = new System.Windows.Forms.Label();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.btnHienThi = new System.Windows.Forms.Button();
            this.btnTiep = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.lblHienThi2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNhapPass
            // 
            this.lblNhapPass.AutoSize = true;
            this.lblNhapPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNhapPass.Location = new System.Drawing.Point(16, 36);
            this.lblNhapPass.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhapPass.Name = "lblNhapPass";
            this.lblNhapPass.Size = new System.Drawing.Size(120, 17);
            this.lblNhapPass.TabIndex = 0;
            this.lblNhapPass.Text = "Nhap Password";
            // 
            // lblHienThi
            // 
            this.lblHienThi.AutoSize = true;
            this.lblHienThi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHienThi.Location = new System.Drawing.Point(75, 81);
            this.lblHienThi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHienThi.Name = "lblHienThi";
            this.lblHienThi.Size = new System.Drawing.Size(64, 17);
            this.lblHienThi.TabIndex = 1;
            this.lblHienThi.Text = "Hien thi";
            this.lblHienThi.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtPass
            // 
            this.txtPass.Location = new System.Drawing.Point(163, 32);
            this.txtPass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPass.Name = "txtPass";
            this.txtPass.PasswordChar = '*';
            this.txtPass.Size = new System.Drawing.Size(213, 22);
            this.txtPass.TabIndex = 2;
            // 
            // btnHienThi
            // 
            this.btnHienThi.Location = new System.Drawing.Point(61, 130);
            this.btnHienThi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnHienThi.Name = "btnHienThi";
            this.btnHienThi.Size = new System.Drawing.Size(100, 28);
            this.btnHienThi.TabIndex = 3;
            this.btnHienThi.Text = "Hien thi";
            this.btnHienThi.UseVisualStyleBackColor = true;
            this.btnHienThi.Click += new System.EventHandler(this.btnHienThi_Click);
            // 
            // btnTiep
            // 
            this.btnTiep.Location = new System.Drawing.Point(169, 130);
            this.btnTiep.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTiep.Name = "btnTiep";
            this.btnTiep.Size = new System.Drawing.Size(100, 28);
            this.btnTiep.TabIndex = 3;
            this.btnTiep.Text = "Tiep";
            this.btnTiep.UseVisualStyleBackColor = true;
            this.btnTiep.Click += new System.EventHandler(this.btnTiep_Click);
            // 
            // btnDong
            // 
            this.btnDong.Location = new System.Drawing.Point(277, 130);
            this.btnDong.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(100, 28);
            this.btnDong.TabIndex = 3;
            this.btnDong.Text = "Dong";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // lblHienThi2
            // 
            this.lblHienThi2.AutoSize = true;
            this.lblHienThi2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHienThi2.Location = new System.Drawing.Point(165, 81);
            this.lblHienThi2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHienThi2.Name = "lblHienThi2";
            this.lblHienThi2.Size = new System.Drawing.Size(188, 17);
            this.lblHienThi2.TabIndex = 1;
            this.lblHienThi2.Text = "                                    ";
            this.lblHienThi2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(407, 186);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnTiep);
            this.Controls.Add(this.btnHienThi);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.lblHienThi2);
            this.Controls.Add(this.lblHienThi);
            this.Controls.Add(this.lblNhapPass);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = " Su dung Label & Textbox";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNhapPass;
        private System.Windows.Forms.Label lblHienThi;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.Button btnHienThi;
        private System.Windows.Forms.Button btnTiep;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.Label lblHienThi2;
    }
}

