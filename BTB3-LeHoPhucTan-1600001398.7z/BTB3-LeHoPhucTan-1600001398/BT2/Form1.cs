﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BT2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        //Click BUTTON
        private void btn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Button was touch!");
        }

        //Load
        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Hi, :)))");
        }

        //Click FORM
        private void Form1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Form was touch!");
        }
    }
}
