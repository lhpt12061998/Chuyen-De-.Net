﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BT4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void lblMessage_TextChanged(object sender, EventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        //Display
        private void btnDisplay_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "Name:            " +txtName.Text + "\n" +"Message:       "+ txtMessage.Text;
        }

        //Clear
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtName.Clear();
            txtMessage.Clear();
            lblMessage.Text = "";
            txtName.Focus();
        }

        //Exit
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Color
        private void radRed_CheckedChanged(object sender, EventArgs e)
        {
            lblMessage.ForeColor = radRed.ForeColor;
        }
        private void radGreen_CheckedChanged(object sender, EventArgs e)
        {
            lblMessage.ForeColor = radGreen.ForeColor;
        }
        private void radBlue_CheckedChanged(object sender, EventArgs e)
        {
            lblMessage.ForeColor = radBlue.ForeColor;
        }
        private void radBlack_CheckedChanged(object sender, EventArgs e)
        {
            lblMessage.ForeColor = radBlack.ForeColor;
        }


        //Hien an Message
        private void chkMessageVisible_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMessageVisible.Checked == true)
                lblMessage.Visible = true;
            else
                lblMessage.Visible = false;
        }


        //Hien an Hinh
        private void picBig_Click(object sender, EventArgs e)
        {
            if (picBig.Visible == true && picSmall.Visible == true)
            {
                picBig.Visible = true;
                picSmall.Visible = false;
            }
            else
            {
                picBig.Visible = false;
                picSmall.Visible = true;
            }
        }
        private void picSmall_Click(object sender, EventArgs e)
        {
            if (picBig.Visible == true && picSmall.Visible == true)
            {
                picBig.Visible = false;
                picSmall.Visible = true;
            }
            else
            {
                picBig.Visible = true;
                picSmall.Visible = false;
            }
        }

       
    }
}
