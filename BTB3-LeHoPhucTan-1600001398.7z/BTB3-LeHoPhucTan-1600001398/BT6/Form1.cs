﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BT6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }



        //Exit
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        //Phep toan
        private void btnCong_Click(object sender, EventArgs e)
        {
            double a = 0, b = 0, c;
            if (txtSo1.Text == "")
            {
                MessageBox.Show("Bạn chưa nhập số !");
                return;
            }
            try
            {
                a = Convert.ToDouble(txtSo1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Bạn nhập sai kiểu dữ liệu !");
            }
            if (txtSo2.Text == "")
            {
                MessageBox.Show("Bạn chưa nhập số !");
                return;
            }
            try
            {
                b = Convert.ToDouble(txtSo2.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Bạn nhập sai kiểu dữ liệu !");
            }
            c = a + b;
            lblKetQua.Text = c.ToString();
        }
        private void btnTru_Click(object sender, EventArgs e)
        {
            double a = 0, b = 0, c;
            if (txtSo1.Text == "")
            {
                MessageBox.Show("bạn chưa nhập a!");
                return;
            }
            try
            {
                a = Convert.ToDouble(txtSo1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Bạn nhập sai kiểu dữ liệu!");
            }
            if (txtSo2.Text == "")
            {
                MessageBox.Show("bạn chưa nhập b!");
                return;
            }
            try
            {
                b = Convert.ToDouble(txtSo2.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Bạn nhập sai kiểu dữ liệu!");
            }
            c = a - b;
            lblKetQua.Text = c.ToString();
        }
        private void btnNhan_Click(object sender, EventArgs e)
        {
            double a = 0, b = 0, c;
            if (txtSo1.Text == "")
            {
                MessageBox.Show("bạn chưa nhập a!");
                return;
            }
            try
            {
                a = Convert.ToDouble(txtSo1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Bạn nhập sai kiểu dữ liệu!");
            }
            if (txtSo2.Text == "")
            {
                MessageBox.Show("bạn chưa nhập b!");
                return;
            }
            try
            {
                b = Convert.ToDouble(txtSo2.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Bạn nhập sai kiểu dữ liệu!");
            }
            c = a * b;
            lblKetQua.Text = c.ToString();
        }
        private void btnChia_Click(object sender, EventArgs e)
        {
            double a = 0, b = 0, c;
            if (txtSo1.Text == "")
            {
                MessageBox.Show("bạn chưa nhập a!");
                return;
            }
            try
            {
                a = Convert.ToDouble(txtSo1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Bạn nhập sai kiểu dữ liệu!");
            }
            if (txtSo2.Text == "")
            {
                MessageBox.Show("bạn chưa nhập b!");
                return;
            }
            try
            {
                b = Convert.ToDouble(txtSo2.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Bạn nhập sai kiểu dữ liệu!");
            }
            c = a / b;
            lblKetQua.Text = c.ToString();
        }
    }
}
